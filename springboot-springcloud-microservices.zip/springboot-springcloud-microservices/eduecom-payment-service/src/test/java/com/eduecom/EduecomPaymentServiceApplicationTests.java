package com.eduecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduecomPaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
