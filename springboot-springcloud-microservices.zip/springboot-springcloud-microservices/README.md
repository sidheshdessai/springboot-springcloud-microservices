# springboot-springcloud-microservices
Spring boot spring cloud project, eureka server, api gateway, config server, zipkin and micrometer for observability (metrics,logging and distributed tracing), postgres, spring data jpa
