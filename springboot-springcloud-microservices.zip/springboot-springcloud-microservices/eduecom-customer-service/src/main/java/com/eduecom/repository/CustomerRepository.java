package com.eduecom.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eduecom.bean.Customer;

public interface CustomerRepository extends JpaRepository<Customer, UUID> {

	public Customer getByUsername(String username);
}
