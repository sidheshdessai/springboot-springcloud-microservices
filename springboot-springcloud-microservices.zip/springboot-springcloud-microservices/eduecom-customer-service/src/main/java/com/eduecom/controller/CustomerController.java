package com.eduecom.controller;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eduecom.bean.Customer;
import com.eduecom.bean.DefaultConfig;
import com.eduecom.configuration.Configuration;
import com.eduecom.repository.CustomerRepository;
import com.fasterxml.jackson.core.JsonProcessingException;

@RestController
@RequestMapping("/api/v1/customer")
public class CustomerController {

    private static final Logger log = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
	private Configuration configuration;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@GetMapping("/getDefaultConfigData")
	public DefaultConfig retrieveCustomerData() {
		return new DefaultConfig(configuration.getName(), configuration.getAge());
	}
	
	@PostMapping("/register")
    public ResponseEntity<Customer> register(@RequestBody Customer customer) throws JsonProcessingException {
		
           customer.setCustomerId(UUID.randomUUID());

           customerRepository.save(customer);
           //redisTemplate.opsForValue().set(credential.getCitizenid().toString(), credential.getPassword());

            //producer.pubSocialEvent_1("REGISTER",credential.getId());
            return  ResponseEntity.ok(customer);
    }
	
	@GetMapping("/{username}/retrieve")
	public Customer getCustomerData(@PathVariable String username) {
		return customerRepository.getByUsername(username);
	}
}
