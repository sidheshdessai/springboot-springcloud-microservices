package com.eduecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduecomConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
