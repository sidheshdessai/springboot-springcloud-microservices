package com.eduecom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduecomInventoryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduecomInventoryServiceApplication.class, args);
	}

}
